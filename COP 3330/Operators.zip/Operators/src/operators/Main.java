/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operators;

/**
 *
 * @author kwhiting
 */

public class Main 
{
    public static void main(String[] args)
    {    
        System.out.println("Starting in the main method");
        // instantiated an instance of class Operators, named operators
        // operators is an instance of class Operators
        // instantiation is accomplished by calling the constructor for the class
        // that happens via new Operators()
        Operators operators = new Operators();
        // method toString() is inherited from superclass Object
        // every single class in Java is a subclass to class Object automatically
        operators.toString();
        operators.operatorExamples();
        
    }  
}
