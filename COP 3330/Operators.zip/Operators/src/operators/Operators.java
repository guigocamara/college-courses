/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package operators;

import javax.swing.JOptionPane;


/**
 *
 * @author kwhiting
 */
public class Operators
{

    /**
     * @param args the command line arguments
     */
    public void operatorExamples() 
    {
        // Arithmetic
        
        int result = 1 + 2;
        // explicit type casting of a float 1.0 to make it
        // and int

        int iResult = result + (int)1.0;
        Integer intClass = Integer.valueOf(iResult);
        String sResult = String.valueOf(result);
        sResult = "12.34";
        // returns back double 12.34
        double fResult = Float.parseFloat(sResult) + 1.0;
        // fails
        int intResult = Integer.parseInt(sResult);
        
        // result is now 3
        // System.out.println() is a static method call...
        System.out.println("1 + 2 = " + result);
        System.out.println("1 + 2 = " + (1 + 2));

        int original_result = result;

        result = result - 1;
        // result is now 2
        System.out.println(original_result + " - 1 = " + result);
        original_result = result;

        result = result * 2;
        // result is now 4
        System.out.println(original_result + " * 2 = " + result);
        original_result = result;

        result = result / 2;
        // result is now 2
        System.out.println(original_result + " / 2 = " + result);
        original_result = result;

        result = result + 8;
        // result is now 10
        System.out.println(original_result + " + 8 = " + result);
        original_result = result;

        result = result % 7;
        // result is now 3
        System.out.println(original_result + " % 7 = " + result);
        
        // concatenation
        String firstString = "This is";
        String secondString = " a concatenated string.";
        String thirdString = firstString + secondString;
        System.out.println(thirdString);
        int data = 1+2;
        System.out.println("Adding 1 + 2 = " + result );
        
        System.out.println(" is the result of 1 + 2 = " + (2 + 2)  );
       
        // unary operators
        int value = +1;
        // result is now 1
        System.out.println(value);
        value--;
        
        // result is now 0
        System.out.println(value);

        value++;
        // result is now 1
        System.out.println(value);

        value = -value;
        // result is now -1
        System.out.println(value);

        boolean success = false;
        Boolean bool = new Boolean(true);
        
        while(true)
        {
            boolean quit = false;
            
            
            if(quit)
            {
                break;
                
            }
        }
        // false
        System.out.println(success);
        // true
        System.out.println(!success);
        
        // prefix and postfix 
        int i = 3;
        i++;
        // prints 4
        System.out.println(i);
        ++i;			   
        
        // prints 5
        System.out.println(i);
        
        // prints 6
        System.out.println(++i);
        
        // prints 6
        System.out.println(i++);
        
       // prints 7
        System.out.println(i);
        
        // Equality and relational
          String fname = "Karin";
          String lname = "karin";
          if(fname.equals(lname))
          if(fname == lname)
                System.out.println("names are equal");
          else
                System.out.println("names are not equal");
          
        int value1 = 4;
        int value2 = 4;
        if(value1 == value2)
            System.out.println("value1 == value2");
        if(value1 != value2)
            System.out.println("value1 != value2");
        if(value1 > value2)
            System.out.println("value1 > value2");
        if(value1 >= value2)
            System.out.println("value1 >= value2");        
        if(value1 < value2)
            System.out.println("value1 < value2");
        if(value1 <= value2)
            System.out.println("value1 <= value2");
        
        // conditional
        int value3 = 3;
        int value4 = 2;
        
        if((value3 == 1) && (value4 == 2))
            System.out.println("value3 is 1 AND value4 is 2");
        if((value3 == 4) || (value4 == 2))
            System.out.println("value3 is 1 OR value4 is 1");
        
        // ternary 
        int value5 = 1;
        int value6 = 2;
        int result1 = JOptionPane.showConfirmDialog(null, "Are you ready to code?", "Ready", JOptionPane.YES_NO_CANCEL_OPTION);
        boolean someCondition = true;
        System.out.print(result1);
        //              operand 1      ? operand 2   : operand 3
        //              if(value == 1) ? true result : false result
        int returnVal = (value5 == 1) ? 10 : 0;
        
        if(value5 == 1)
            returnVal = 10;
        else 
            returnVal = 0;
        
        System.out.println((result1 == JOptionPane.YES_OPTION) ? "You are ready" : "You are not ready");
        
        if(result1 == JOptionPane.YES_OPTION) 
            System.out.println("You are ready");
        else
            System.out.println("You are not ready");

        System.out.println(result1);
        
        // static method call, do not instanatiate an instance
        // of the class
        Math.random();
        //Math math = new Math();
        
        
        // instanceof
        // all primative data types in Java have a corresponding
        // class (example int has Integer; float has Float; double has Double)
        int var = 5;
        
        Integer variable = new Integer(5);
        
        Parent parent = new Parent();
        Child child = new Child();

        System.out.println("variable instanceof Integer: "
            + (variable instanceof Integer));

        System.out.println("parent instanceof Parent: "
            + (parent instanceof Parent));
        System.out.println("parent instanceof Child: "
            + (parent instanceof Child));
        System.out.println("parent instanceof MyInterface: "
            + (parent instanceof MyInterface));
        System.out.println("child instanceof Parent: "
            + (child instanceof Parent));
        System.out.println("child instanceof Child: "
            + (child instanceof Child));
        System.out.println("child instanceof MyInterface: "
            + (child instanceof MyInterface));
        System.out.println("child instanceof Object: "
            + (child instanceof Object));  
    
        if(value1 == value2)
            if(value3 == value4)
                    System.out.println("all values are equal");
    }
    
    // inner class
    private static class Parent {}
    
    // polymorphism!!!!
    // four identities:
    // is of type Child
    // is of type Parent
    // is of type MyInterface
    // all classes in Java are subclasses to class Object
    private static class Child extends Parent implements MyInterface {}

    private interface MyInterface {}
}
