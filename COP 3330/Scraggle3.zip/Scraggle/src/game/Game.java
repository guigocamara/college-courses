/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import dictionary.Alphabet;
import dictionary.Dictionary;
import model.GridPoint;
import model.GridUnit;

/**
 *
 * @author guica
 */
public class Game {
    
    private final GridUnit [][] grid;
    
    public Game(Dictionary dictionary)
    {
        this.grid = new GridUnit[4][4]; // creates 4x4 grid
        this.populateGrid();
    }    
    
    public GridUnit[][] getGrid()
    {
        return grid;
    }

     public GridUnit getGridUnit(GridPoint point)
       {
           return grid[point.x][point.y];
       }
     
     private void populateGrid() // populates 4 rows and 4 columns with letters
     {
         for (int i = 0; i < 4; i = ++i) // rows
         {
            for (int j = 0; j < 4; j = ++j) // columns 
            {
               grid[i][j] = new GridUnit(Alphabet.newRandom(),new GridPoint(i,j));
            }
         }
     }
     
     public void displayGrid() // displays populated grid to console
     {
         System.out.println("-------------------------");
         for(int i = 0; i < 4; ++i)
         {
             System.out.print("|  ");
             
             for(int j = 0; j < 4; ++j)
             {
                 System.out.print(grid[i][j].getLetter());
                 System.out.print("  |  ");
             }
             
             System.out.println("\n-------------------------");
         }
     }
}
