/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;



import game.Game;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.*;

/**
 *
 * @author guica
 */
public class ScraggleUi {
    
        private JFrame frame;
        
        // Menu bar
        private JMenuBar menuBar;
        private JMenu gameMenu;
        private JMenuItem exit;
        private JMenuItem newGame;
    
        // West panel
        private JPanel scragglePanel;
        private JButton[][] diceButtons;
        
        // East panel 
        private JPanel wordsPanel;
        private JScrollPane scrollPane;
        private JTextPane wordsArea;
        private JLabel timeLabel;
        private JButton shakeDice;
        
        // South panel
        private JPanel currentPanel;
        private JLabel currentWord;
        private JButton currentSubmit;
        private JLabel scoreLabel;
        
        Game game;
        
        private final int GRID = 4;
        
        public ScraggleUi(Game inGame)
        {
            game = inGame;
            
            initComponents();
        }
        
        private void initComponents()
        {
            // Initialize the JFrame
            frame = new JFrame("Scraggle");
            frame.setSize(500,600);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            // Construct menu bar and menu items
            menuBar = new JMenuBar();
            
            gameMenu = new JMenu("Scraggle");
            
            newGame = new  JMenuItem("New Game");
            gameMenu.add(newGame);
                
            exit = new JMenuItem("Exit");
            gameMenu.add(exit);
            
            menuBar.add(gameMenu);
            frame.setJMenuBar(menuBar);
            
             // Call methods for each panel
             westPanel();
             southPanel();
             eastPanel();
            
             frame.pack();
             frame.show();
        }
        
        
        private void westPanel(){
            scragglePanel = new JPanel(new GridLayout(4,4,1,1));
            scragglePanel.setPreferredSize(new Dimension(400,300));
            scragglePanel.setBorder(BorderFactory.createTitledBorder("Scraggle Board"));
            
            diceButtons = new JButton[GRID][GRID];
        
        // populate dice buttons
        for(int r = 0; r < GRID; r++){
        for(int c = 0; c < GRID; c++)
        {
            diceButtons[r][c] = new JButton();
            diceButtons[r][c].setBackground(Color.RED);
            //diceButtons[r][c].setForeground(Color.WHITE);
            
            scragglePanel.add(diceButtons[r][c]);
        } 
            frame.getContentPane().add(scragglePanel, BorderLayout.CENTER);
        }
    }
        
       private void southPanel(){
            
            currentPanel = new JPanel();
            currentPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
            currentPanel.setBorder(BorderFactory.createTitledBorder("Current Word"));
            currentPanel.setMinimumSize(new Dimension(400,100));
            currentPanel.setPreferredSize(new Dimension(400,100));
            
            // Current word label
            currentWord = new JLabel();
            currentWord.setBorder(BorderFactory.createTitledBorder("Current Word"));
            currentWord.setMinimumSize(new Dimension(200,55));
            currentWord.setPreferredSize(new Dimension(200,55));
            
            // Submit word button
            currentSubmit = new JButton("Submit word");
            currentSubmit.setMinimumSize(new Dimension(200,55));
            currentSubmit.setPreferredSize(new Dimension(200,55));
            
            // Score label
            scoreLabel = new JLabel();
            scoreLabel.setBorder(BorderFactory.createTitledBorder("Score"));
            scoreLabel.setMinimumSize(new Dimension(150,70));
            scoreLabel.setPreferredSize(new Dimension(150,70));
            
            
            currentPanel.add(currentWord);
            currentPanel.add(currentSubmit);
            currentPanel.add(scoreLabel);
            
            
            frame.getContentPane().add(currentPanel,BorderLayout.SOUTH);
           
       }
               
 
       private void eastPanel(){
       
           wordsPanel = new JPanel(new GridLayout(3,1,5,5));
           wordsPanel.setBorder(BorderFactory.createTitledBorder("Enter Words Found"));
           wordsPanel.setPreferredSize(new Dimension(200,30));

           // Text area and scroll pane
           wordsArea = new JTextPane();
           wordsArea.setMinimumSize(new Dimension(200,100));
           wordsArea.setPreferredSize(new Dimension(200,100));
           scrollPane = new JScrollPane(wordsArea);
           scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
           scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
           wordsPanel.add(scrollPane);
           
          
           // Time left label
           timeLabel = new JLabel("3:00", JLabel.CENTER);
           timeLabel.setFont(new Font("Serif", Font.PLAIN, 40));
           timeLabel.setBorder(BorderFactory.createTitledBorder("Time Left"));

           // Shake dice label
           shakeDice = new JButton("Shake Dice");


           wordsPanel.add(timeLabel);
           wordsPanel.add(shakeDice);
           
           
           frame.getContentPane().add(wordsPanel, BorderLayout.EAST);
           
       }
       
    }

    
    

            