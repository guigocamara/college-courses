/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;



import game.Game;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;
import java.awt.Image;


import javax.swing.*;

/**
 *
 * @author guica
 */
public class ScraggleUi 
{
    
        private JFrame frame;
        
        // Menu bar
        private JMenuBar menuBar;
        private JMenu gameMenu;
        private JMenuItem exit;
        private JMenuItem newGame;
    
        // West panel
        private JPanel scragglePanel;
        private JButton[][] diceButtons;
        
        // East panel 
        private JPanel wordsPanel;
        private JScrollPane scrollPane;
        private JTextPane wordsArea;
        private JLabel timeLabel;
        private JButton shakeDice;
        
        // South panel
        private JPanel currentPanel;
        private JLabel currentWord;
        private JButton currentSubmit;
        private JLabel scoreLabel;
        private int score;
        private static Timer timer;
        private static int minutes = 3;
        private static int seconds = 0;
        
        private Game game;
       
        private ArrayList<String> foundWords;
        
        
        private final int GRID = 4;
        
        private ResetGameListener resetGameListener;
        
        
        
        public ScraggleUi(Game inGame)
        {
            game = inGame;
            
            initObjects();
            initComponents();
        }
        
        
        private void initObjects()
        {
            resetGameListener = new ResetGameListener();
            foundWords = new ArrayList();
        }

        
        private void initComponents()
        {
            // Initialize the JFrame
            frame = new JFrame("Scraggle");
            frame.setSize(500,600);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            // Construct menu bar and menu items
            menuBar = new JMenuBar();
            
            gameMenu = new JMenu("Scraggle");
            
            newGame = new  JMenuItem("New Game");
            gameMenu.add(newGame);
            newGame.addActionListener(resetGameListener);
                
            exit = new JMenuItem("Exit");
            gameMenu.add(exit);
            ExitListener exitListener = new ExitListener();
            exit.addActionListener(exitListener);
            
            menuBar.add(gameMenu);
            frame.setJMenuBar(menuBar);
            
             // Call methods for each panel
             westPanel();
             southPanel();
             eastPanel();
             
             setupTimer(); // initializes timer
            
             frame.pack();
             frame.show();
             
             
        }
        
        //method to resize images for the buttons
        private ImageIcon imageResize(ImageIcon icon)
        {
        Image image = icon.getImage();
        Image newImage = image.getScaledInstance(95, 95, java.awt.Image.SCALE_SMOOTH);
        icon = new ImageIcon(newImage);
        return icon;
        }
        
     
        
        private void westPanel(){
            scragglePanel = new JPanel(new GridLayout(4,4,1,1));
            scragglePanel.setPreferredSize(new Dimension(400,300));
            scragglePanel.setBorder(BorderFactory.createTitledBorder("Scraggle Board"));
            
            diceButtons = new JButton[GRID][GRID];
        
        // populate dice buttons
        for(int r = 0; r < GRID; r++){
        for(int c = 0; c < GRID; c++)
        {
            /*
            diceButtons[r][c] = new JButton();
            diceButtons[r][c].setBackground(Color.RED);
            //diceButtons[r][c].setForeground(Color.WHITE);
            */
            
            URL imgURL = getClass().getResource(game.getGrid()[r][c].getImgPath());
            ImageIcon icon = new ImageIcon(imgURL);
            icon = imageResize(icon);
            
            diceButtons[r][c] = new JButton(icon);
            diceButtons[r][c].putClientProperty("row", r);
            diceButtons[r][c].putClientProperty("col", c);
            diceButtons[r][c].putClientProperty("letter", game.getGrid()[r][c].getLetter());
            TileListener tileListener = new TileListener();
            LetterListener letterListener = new LetterListener();
            diceButtons[r][c].addActionListener(tileListener);
            diceButtons[r][c].addActionListener(letterListener);
            
            
            
                    
            scragglePanel.add(diceButtons[r][c]);
        } 
            frame.getContentPane().add(scragglePanel, BorderLayout.CENTER);
        }
    }
        
       private void southPanel(){
            
            currentPanel = new JPanel();
            currentPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
            currentPanel.setBorder(BorderFactory.createTitledBorder("Current Word"));
            currentPanel.setMinimumSize(new Dimension(400,100));
            currentPanel.setPreferredSize(new Dimension(400,100));
            
            // Current word label
            currentWord = new JLabel();
            currentWord.setBorder(BorderFactory.createTitledBorder("Current Word"));
            currentWord.setMinimumSize(new Dimension(200,55));
            currentWord.setPreferredSize(new Dimension(200,55));
            
            // Submit word button
            currentSubmit = new JButton("Submit word");
            currentSubmit.setMinimumSize(new Dimension(200,55));
            currentSubmit.setPreferredSize(new Dimension(200,55));
            SubmitListener submitListener = new SubmitListener();
            currentSubmit.addActionListener(submitListener);
            
            
            // Score label
            scoreLabel = new JLabel();
            scoreLabel.setBorder(BorderFactory.createTitledBorder("Score"));
            scoreLabel.setMinimumSize(new Dimension(150,70));
            scoreLabel.setPreferredSize(new Dimension(150,70));
            
            
            currentPanel.add(currentWord);
            currentPanel.add(currentSubmit);
            currentPanel.add(scoreLabel);
            
            
            frame.getContentPane().add(currentPanel,BorderLayout.SOUTH);
           
       }
               
 
       private void eastPanel(){
       
           wordsPanel = new JPanel(new GridLayout(3,1,5,5));
           wordsPanel.setBorder(BorderFactory.createTitledBorder("Enter Words Found"));
           wordsPanel.setPreferredSize(new Dimension(200,30));

           // Text area and scroll pane
           wordsArea = new JTextPane();
           wordsArea.setMinimumSize(new Dimension(200,100));
           wordsArea.setPreferredSize(new Dimension(200,100));
           scrollPane = new JScrollPane(wordsArea);
           scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
           scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
           wordsPanel.add(scrollPane);
           
          
           // Time left label
           timeLabel = new JLabel("3:00", JLabel.CENTER);
           timeLabel.setFont(new Font("Serif", Font.PLAIN, 40));
           timeLabel.setBorder(BorderFactory.createTitledBorder("Time Left"));

           // Shake dice label
           shakeDice = new JButton("Shake Dice");
           shakeDice.addActionListener(resetGameListener);


           wordsPanel.add(timeLabel);
           wordsPanel.add(shakeDice);
           
           
           frame.getContentPane().add(wordsPanel, BorderLayout.EAST);
           
       }
       
        // method to setup timer
        private class TimerListener implements ActionListener {

                @Override
                public void actionPerformed(ActionEvent ae) 
                {
                    if(seconds == 0 && minutes == 0)
            {              
                timer.stop();
                JOptionPane.showMessageDialog(frame, "Time is up! Game over!");
            }
            else
            {
                if(seconds == 0)
                {
                    seconds = 59;
                    minutes--;
                }
                else
                {
                    seconds--;
                }
            }

            if(seconds < 10)
            {
                String strSeconds = "0" + String.valueOf(seconds);
                timeLabel.setText(String.valueOf(minutes) + ":" + strSeconds);
            }
            else
            {
                timeLabel.setText(String.valueOf(minutes) + ":" + String.valueOf(seconds));
            }
                }
            
        }
        
        private void setupTimer()
        {
            timer = new Timer(1000, new TimerListener());
            timer.start();
        }
       
       
       
       // method to exit window
        private class ExitListener implements ActionListener {

        @Override
        public void actionPerformed(java.awt.event.ActionEvent ae) 
            {
            int response = JOptionPane.showConfirmDialog(frame,"Confirm to exit Scraggle?",
                    "Exit?", JOptionPane.YES_NO_OPTION);
            
            if(response == JOptionPane.YES_OPTION)
                System.exit(0);
            }
        }
        
        // method to reset game window
        private class ResetGameListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            score = 0;
            game.populateGrid();
            
            frame.remove(scragglePanel);
            scragglePanel.removeAll();
            
            
            scragglePanel = new JPanel(new GridLayout(4,4,1,1));
            scragglePanel.setPreferredSize(new Dimension(400,300));
            scragglePanel.setBorder(BorderFactory.createTitledBorder("Scraggle Board"));
            
            diceButtons = new JButton[GRID][GRID];
        
            // populate dice buttons
            for(int r = 0; r < GRID; r++)
            {
            for(int c = 0; c < GRID; c++)
                {
            
            URL imgURL = getClass().getResource(game.getGrid()[r][c].getImgPath());
            ImageIcon icon = new ImageIcon(imgURL);
            icon = imageResize(icon);
            
            diceButtons[r][c] = new JButton(icon);
            diceButtons[r][c].putClientProperty("row", r);
            diceButtons[r][c].putClientProperty("col", c);
            diceButtons[r][c].putClientProperty("letter", game.getGrid()[r][c].getLetter());
            TileListener tileListener = new TileListener();
            LetterListener letterListener = new LetterListener();
            diceButtons[r][c].addActionListener(tileListener);
            diceButtons[r][c].addActionListener(letterListener);
                
             
                scragglePanel.add(diceButtons[r][c]);
                } 
            }
            
            scragglePanel.revalidate();
            scragglePanel.repaint();
            
            frame.getContentPane().add(scragglePanel, BorderLayout.CENTER);
            
            wordsArea.setText("");
            scoreLabel.setText("0");
            currentWord.setText("");
            timeLabel.setText("3:00");
            
            foundWords.removeAll(foundWords); 
            
            timer.stop();
            minutes = 3;
            seconds = 0;
            timer.start();
            
            
            }
        }
        
       
        private void updateTextArea(String data)
        {
            wordsArea.setText(wordsArea.getText() + "\n" + data);
            wordsArea.setCaretPosition(wordsArea.getDocument().getLength());
        }
            
        private class SubmitListener implements ActionListener
        {

        @Override
        public void actionPerformed(ActionEvent ae) 
            {
            int wordScore = game.getDictionary().search(currentWord.getText().toLowerCase());
            
            if(foundWords.contains(currentWord.getText().toLowerCase()))
            {
                JOptionPane.showMessageDialog(frame, "Word found already");
            }
            else 
          {    
            if (wordScore > 0)
            {
                updateTextArea(currentWord.getText());
                foundWords.add(currentWord.getText().toLowerCase()); // compare lower case words to lower case words
                score += wordScore;
                scoreLabel.setText(String.valueOf(score));
            }
            else
            {
                JOptionPane.showMessageDialog(frame, "Not a valid word");
            }
          }
            currentWord.setText("");
            
            for (int row = 0; row < GRID; row++)
            {
                for(int col = 0; col < GRID; col++)
                        {
                            diceButtons[row][col].setEnabled(true);
                        }
            }
            
            
            
            }          
        }
        

        // method to figure out which letter is being selected
        private class LetterListener implements ActionListener
        {

        @Override
        public void actionPerformed(ActionEvent ae) 
            {
            if(ae.getSource() instanceof JButton)
                {
                JButton button = (JButton)ae.getSource();
                String letter = (String)button.getClientProperty("letter");
                currentWord.setText(currentWord.getText() + letter);
                }
            }
            
        }
        
        
        
        
        // method to enable and disable tiles accordingly
        private class TileListener implements ActionListener
        {
        
        @Override
        public void actionPerformed(ActionEvent ae) {
            

            // based on the row and col of the JButton clicked
            // enable one row up, one row down, one col left, one col right
            if(ae.getSource() instanceof JButton)
            {
                JButton button = (JButton)ae.getSource();
                
                int row = (int)button.getClientProperty("row");
                int col = (int)button.getClientProperty("col");

                // disables all the JButtons
                for(int i = 0; i < 4; i++)
                {
                    for(int j = 0; j < 4; j++)
                    {
                        diceButtons[i][j].setEnabled(false);
                    }
                }
                
                // enable surroundings
                if(row == 0 && col == 0) // top left corner
                {                    
                    diceButtons[row + 1][col].setEnabled(true);
                    diceButtons[row + 1][col + 1].setEnabled(true);
                    diceButtons[row][col + 1].setEnabled(true);
                }
                
                if(row == 0 && (col > 0 && col < 3)) // upper middle
                {
                    diceButtons[row][col - 1].setEnabled(true);
                    diceButtons[row + 1][col - 1].setEnabled(true);
                    diceButtons[row + 1][col].setEnabled(true);
                    diceButtons[row + 1][col + 1].setEnabled(true);
                    diceButtons[row][col + 1].setEnabled(true);
                }
                
                if(row == 0 && col == 3) // top right corner
                {    
                    diceButtons[row][col - 1].setEnabled(true);
                    diceButtons[row + 1][col].setEnabled(true);
                    diceButtons[row + 1][col - 1].setEnabled(true);
                }
                
                 if((row > 0 && row < 3) && col == 0) // left middle
                {
                    diceButtons[row - 1][col].setEnabled(true);
                    diceButtons[row - 1][col + 1].setEnabled(true);
                    diceButtons[row][col + 1].setEnabled(true);
                    diceButtons[row + 1][col + 1].setEnabled(true);
                    diceButtons[row + 1][col].setEnabled(true);
                }
                
                if((row > 0 && row < 3) && col == 3) // right middle
                {
                    diceButtons[row - 1][col].setEnabled(true);
                    diceButtons[row - 1][col - 1].setEnabled(true);
                    diceButtons[row][col - 1].setEnabled(true);
                    diceButtons[row + 1][col - 1].setEnabled(true);
                    diceButtons[row + 1][col].setEnabled(true);
                }
                
                
                // this logic only works for row 1, 2 and col 1, 2
                if((row == 1 && col == 1) || (row == 2 && col == 2) || (row == 1 && col == 2) || (row == 2 && col == 1))
                {
                    // row above clicked tile
                    diceButtons[row - 1][col - 1].setEnabled(true);
                    diceButtons[row - 1][col].setEnabled(true);
                    diceButtons[row - 1][col + 1].setEnabled(true);

                    // the row clicked tile
                    diceButtons[row][col - 1].setEnabled(true);
                    diceButtons[row][col + 1].setEnabled(true);
                    
                    // row below clicked tile
                    diceButtons[row + 1][col - 1].setEnabled(true);
                    diceButtons[row + 1][col].setEnabled(true);
                    diceButtons[row + 1][col + 1].setEnabled(true);
                }
                
                
                if(row == 3 && col == 0) // bottom left corner
                {
                    diceButtons[row - 1][col].setEnabled(true);
                    diceButtons[row - 1][col + 1].setEnabled(true);
                    diceButtons[row][col + 1].setEnabled(true);
                }
                
                
                if(row == 3 && (col > 0 && col < 3)) // // lower middle
                {
                    diceButtons[row][col - 1].setEnabled(true);
                    diceButtons[row - 1][col - 1].setEnabled(true);
                    diceButtons[row - 1][col].setEnabled(true);
                    diceButtons[row - 1][col + 1].setEnabled(true);
                    diceButtons[row][col + 1].setEnabled(true);
                }
                
                
                if(row == 3 && col == 3) // bottom right corner
                {    
                    diceButtons[row -1][col].setEnabled(true);
                    diceButtons[row - 1][col - 1].setEnabled(true);
                    diceButtons[row][col - 1].setEnabled(true);
                }                
                
                }
          
             }
            }
    }    